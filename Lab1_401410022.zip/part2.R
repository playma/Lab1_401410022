answer <- sum(1:100*1:100)
n <- 1:100
n*n
sum(n*n)
print(answer)

?iris #dataset
?InsectSprays
?seq
?mean
?stats
?swirl

seq(1, 9, by = 2)

